# CHANDAN AI STUDIO — Android starter

This is the first Flutter UI starter for CHANDAN AI STUDIO.

## What is included
- Dark premium home screen
- AI Photo, Photo Editor, AI Video, Photo-to-Video, Face Tools, Voice & Music cards
- Gallery and Profile navigation placeholders
- Safety notice

## Important
This is a UI starter, not a finished AI app. AI generation, image upload, login, payments, private cloud storage, age verification, and moderation are not connected yet. Do not add secret API keys to the mobile app. AI provider requests should go through a secure backend.

## Run on a computer with Flutter installed
1. Install Flutter SDK and Android Studio.
2. Extract this project.
3. Run `flutter pub get`.
4. Run `flutter run`.

## Build Android APK
Run `flutter build apk --release`. The APK is created at:
`build/app/outputs/flutter-apk/app-release.apk`

## Mobile-only workflow
You can upload this ZIP to a compatible cloud development workspace from your Android phone. A cloud build environment is needed to compile the Android APK without a local computer.
